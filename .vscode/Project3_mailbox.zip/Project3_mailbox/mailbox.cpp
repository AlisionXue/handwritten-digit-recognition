#include "Mailbox.h"
#include <iostream>

int main() {
    Mailbox myMail;
    Message message1("Jim", "Bob", "Hello, see ya later!");
    myMail.add_message(message1);

    Message message2("Alice", "Suzie", "I'm running late!");
    Time message2TimeUpdate(6, 21, 44);
    message2.setTime(message2TimeUpdate);
    myMail.add_message(message2);

    std::cout << "Initial mailbox content:\n";
    myMail.print(); // Print all messages

    std::cout << "First message:\n";
    myMail.get_message(0).print(); // Print first message

    myMail.remove_message(0); // Remove the first Message from the Mailbox
    std::cout << "After removing the first message:\n";
    myMail.print(); // Print remaining messages

    return 0;
}
