#ifndef MAILBOX_H_
#define MAILBOX_H_

#include "Message.h"
#include <vector>

class Mailbox {
public:
    Mailbox() = default; // Default constructor initializes an empty mailbox

    void add_message(const Message& m); // Adds a message to the mailbox
    Message get_message(int i) const;   // Retrieves a message by index
    void remove_message(int i);         // Removes a message by index
    void print() const;                 // Prints all messages in the mailbox

private:
    std::vector<Message> inbox; // Vector to store messages
};

#endif // MAILBOX_H_
#pragma once
