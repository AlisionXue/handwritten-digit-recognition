#include "Mailbox.h"
#include <iostream>

void Mailbox::add_message(const Message& m) {
    inbox.push_back(m);
}

Message Mailbox::get_message(int i) const {
    if (i >= 0 && i < inbox.size()) {
        return inbox[i];
    }
    else {
        throw std::out_of_range("Index out of range");
    }
}

void Mailbox::remove_message(int i) {
    if (i >= 0 && i < inbox.size()) {
        inbox.erase(inbox.begin() + i);
    }
    else {
        throw std::out_of_range("Index out of range");
    }
}

void Mailbox::print() const {
    for (const auto& message : inbox) {
        message.print();
        std::cout << std::endl;
    }
}
