#ifndef TIME_H
#define TIME_H

#include <iostream>

class Time {
public:
    // Constructor to initialize the time object
    Time(int hour = 0, int minute = 0, int second = 0)
        : hour(hour),
#pragma once
