#ifndef MESSAGE_H
#define MESSAGE_H

#include <string>
#include <iostream>

class Message {
public:
    // Constructor to initialize a message with sender, recipient, and the message text
    Message(const std::string& sender, const std::string& recipient, const std::string& messageText)
        : sender(sender), recipient(recipient), messageText(messageText) {}

    // Function to print the message details
    void print() const {
        std::cout << "From: " << sender << "\nTo: " << recipient << "\nMessage: " << messageText << std::endl;
    }

private:
    std::string sender;      // stores the sender of the message
    std::string recipient;   // stores the recipient of the message
    std::string messageText; // stores the text of the message
};

#endif // MESSAGE_H
#pragma once
